# NearByPlaces
It a android mobile app where it using MAP API and find near by place for example hospital, schools, colleges etc. 

[demo](https://youtu.be/OM4woZqyumQ)

APK file [Download](https://www.dropbox.com/s/y3gwn16tqrwmcwy/app-debug.apk?raw=1)
